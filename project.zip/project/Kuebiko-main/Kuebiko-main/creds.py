# You're Twitch Token 
TWITCH_TOKEN = ""
# Your TWITCH Channel Name
TWITCH_CHANNEL = ""
# Your OpenAI API Key
OPENAI_API_KEY = ""
# Your Google Cloud JSON Path
GOOGLE_JSON_PATH = ""
