<title>Twitch Token Generator by swiftyspiffy - API Success</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js"></script>

<br>
<div class="container">
	<div class="panel panel-primary">
		<div class="panel-heading">
			<h3 class="panel-title text-center">Twitch Token Generator - API Success</h3>
		</div>
		<div class="panel-body">
			<span>Thank you for using TwitchTokenGenerator! Your username and auth token has been made available to <b><? echo $title; ?></b>! You may now close this window/tab.</span>
		</div>
	</div>
</div>