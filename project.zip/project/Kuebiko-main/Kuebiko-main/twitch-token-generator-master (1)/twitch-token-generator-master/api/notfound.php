<title>Twitch Token Generator by swiftyspiffy - API Failed</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js"></script>

<style>
.panel-primary>.panel-heading {
	background-color: #d9534f;
	border-color: #d9534f;
}

.panel-primary {
	border-color: #d9534f;
}
</style>

<br>
<div class="container">
	<div class="panel panel-primary">
		<div class="panel-heading">
			<h3 class="panel-title text-center">Twitch Token Generator - API Failed</h3>
		</div>
		<div class="panel-body">
			<span><b>The link you used doesn't appear to be valid!</b> Please check for typos or have your application generate a new authentication link!</span>
		</div>
	</div>
</div>