# Security Policy

## Reporting a Vulnerability

If you've encountered a security issue, please contact me via one of the methods below:

- Discord: [swiftyspiffy#0001](https://discordapp.com/users/92700503183486976)
- Twitter: [swiftyspiffy](https://twitter.com/swiftyspiffy)
- Email: [swiftyspiffy@gmail.com](mailto:swiftyspiffy@gmail.com)
- Twitch (whisper): [swiftyspiffy](https://twitch.tv/swiftyspiffy)

Thanks for helping out!
